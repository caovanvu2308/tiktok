import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import json
import os
import sys
from datetime import datetime
import yt_dlp
from pathlib import Path

class TikTokDownloaderGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("TikTok Downloader - Vũ Vẫn Vậy")
        self.root.geometry("900x750")
        self.root.resizable(False, False)  # Cố định kích thước

        # Đặt icon nếu có
        try:
            self.root.iconbitmap("tiktok.ico")
        except:
            pass

        # Biến lưu trữ
        self.config_file = "tiktok_config.json"
        self.download_path = tk.StringVar(value=str(Path.home() / "Downloads"))
        self.username = tk.StringVar()
        self.max_videos = tk.StringVar()
        self.download_mode = tk.StringVar(value="all")  # "single" hoặc "all"
        self.single_url = tk.StringVar()

        # Load cài đặt đã lưu
        self.load_config()

        # Thiết lập giao diện
        self.setup_ui()

    def load_config(self):
        """Load cài đặt từ file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    self.download_path.set(config.get('download_path', str(Path.home() / "Downloads")))
                    self.username.set(config.get('last_username', ''))
        except Exception:
            pass

    def save_config(self):
        """Lưu cài đặt vào file"""
        try:
            config = {
                'download_path': self.download_path.get(),
                'last_username': self.username.get()
            }
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def setup_ui(self):
        """Thiết lập giao diện"""

        # Header với thương hiệu
        header_frame = tk.Frame(self.root, bg="#1DA1F2", height=80)
        header_frame.pack(fill=tk.X, padx=0, pady=0)
        header_frame.pack_propagate(False)

        title_label = tk.Label(
            header_frame,
            text="🎵 TikTok Video Downloader",
            font=("Arial", 20, "bold"),
            bg="#1DA1F2",
            fg="white"
        )
        title_label.pack(pady=5)

        brand_frame = tk.Frame(header_frame, bg="#1DA1F2")
        brand_frame.pack()

        brand_label = tk.Label(
            brand_frame,
            text="Vũ Vẫn Vậy",
            font=("Arial", 12, "bold"),
            bg="#1DA1F2",
            fg="#FFD700"
        )
        brand_label.pack(side=tk.LEFT, padx=5)

        zalo_label = tk.Label(
            brand_frame,
            text="📞 Zalo: 0983740967",
            font=("Arial", 10),
            bg="#1DA1F2",
            fg="white"
        )
        zalo_label.pack(side=tk.LEFT, padx=5)

        # Main container
        main_container = tk.Frame(self.root, bg="#F0F8FF")
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Mode Selection Frame
        self.mode_frame = tk.LabelFrame(
            main_container,
            text="Chế độ tải",
            font=("Arial", 11, "bold"),
            bg="#F0F8FF",
            fg="#1DA1F2",
            padx=10,
            pady=10
        )
        self.mode_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Radiobutton(
            self.mode_frame,
            text="Tải toàn bộ video từ kênh TikTok",
            variable=self.download_mode,
            value="all",
            font=("Arial", 10),
            bg="#F0F8FF",
            activebackground="#F0F8FF",
            command=self.toggle_mode
        ).pack(anchor=tk.W, pady=2)

        tk.Radiobutton(
            self.mode_frame,
            text="Tải 1 video đơn lẻ",
            variable=self.download_mode,
            value="single",
            font=("Arial", 10),
            bg="#F0F8FF",
            activebackground="#F0F8FF",
            command=self.toggle_mode
        ).pack(anchor=tk.W, pady=2)

        # Input Frame - Toàn bộ kênh
        self.all_frame = tk.LabelFrame(
            main_container,
            text="Tải toàn bộ kênh",
            font=("Arial", 11, "bold"),
            bg="#F0F8FF",
            fg="#1DA1F2",
            padx=10,
            pady=10
        )
        self.all_frame.pack(fill=tk.X, pady=(0, 10))

        # Username
        username_frame = tk.Frame(self.all_frame, bg="#F0F8FF")
        username_frame.pack(fill=tk.X, pady=5)

        tk.Label(
            username_frame,
            text="Username TikTok:",
            font=("Arial", 10),
            bg="#F0F8FF",
            width=18,
            anchor='w'
        ).pack(side=tk.LEFT)

        tk.Entry(
            username_frame,
            textvariable=self.username,
            font=("Arial", 10),
            width=40
        ).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)

        # Max videos
        max_frame = tk.Frame(self.all_frame, bg="#F0F8FF")
        max_frame.pack(fill=tk.X, pady=5)

        tk.Label(
            max_frame,
            text="Số video tối đa:",
            font=("Arial", 10),
            bg="#F0F8FF",
            width=18,
            anchor='w'
        ).pack(side=tk.LEFT)

        tk.Entry(
            max_frame,
            textvariable=self.max_videos,
            font=("Arial", 10),
            width=20
        ).pack(side=tk.LEFT, padx=5)

        tk.Label(
            max_frame,
            text="(Để trống = tất cả)",
            font=("Arial", 9, "italic"),
            bg="#F0F8FF",
            fg="gray"
        ).pack(side=tk.LEFT, padx=5)

        # Input Frame - Video đơn
        self.single_frame = tk.LabelFrame(
            main_container,
            text="Tải video đơn lẻ",
            font=("Arial", 11, "bold"),
            bg="#F0F8FF",
            fg="#1DA1F2",
            padx=10,
            pady=10
        )

        single_url_frame = tk.Frame(self.single_frame, bg="#F0F8FF")
        single_url_frame.pack(fill=tk.X, pady=5)

        tk.Label(
            single_url_frame,
            text="URL Video:",
            font=("Arial", 10),
            bg="#F0F8FF",
            width=18,
            anchor='w'
        ).pack(side=tk.LEFT)

        tk.Entry(
            single_url_frame,
            textvariable=self.single_url,
            font=("Arial", 10),
            width=40
        ).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)

        # Download Path
        path_frame = tk.LabelFrame(
            main_container,
            text="Thư mục lưu",
            font=("Arial", 11, "bold"),
            bg="#F0F8FF",
            fg="#1DA1F2",
            padx=10,
            pady=10
        )
        path_frame.pack(fill=tk.X, pady=(0, 10))

        path_input_frame = tk.Frame(path_frame, bg="#F0F8FF")
        path_input_frame.pack(fill=tk.X)

        tk.Entry(
            path_input_frame,
            textvariable=self.download_path,
            font=("Arial", 10),
            state='readonly'
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        tk.Button(
            path_input_frame,
            text="📁 Chọn thư mục",
            command=self.select_folder,
            font=("Arial", 10),
            bg="#FFD700",
            fg="black",
            cursor="hand2",
            relief=tk.RAISED,
            bd=2
        ).pack(side=tk.LEFT)

        # Buttons
        button_frame = tk.Frame(main_container, bg="#F0F8FF")
        button_frame.pack(fill=tk.X, pady=10)

        self.download_btn = tk.Button(
            button_frame,
            text="⬇️ BẮT ĐẦU TẢI",
            command=self.start_download,
            font=("Arial", 12, "bold"),
            bg="#28a745",
            fg="white",
            cursor="hand2",
            relief=tk.RAISED,
            bd=3,
            height=2
        )
        self.download_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        tk.Button(
            button_frame,
            text="🔄 Làm mới",
            command=self.reset_form,
            font=("Arial", 11),
            bg="#FFA500",
            fg="white",
            cursor="hand2",
            relief=tk.RAISED,
            bd=2,
            height=2
        ).pack(side=tk.LEFT, padx=5)

        tk.Button(
            button_frame,
            text="🔧 Cập nhật yt-dlp",
            command=self.update_ytdlp,
            font=("Arial", 10),
            bg="#6c757d",
            fg="white",
            cursor="hand2",
            relief=tk.RAISED,
            bd=2,
            height=2
        ).pack(side=tk.LEFT, padx=5)

        # Progress Frame
        progress_frame = tk.LabelFrame(
            main_container,
            text="Tiến trình",
            font=("Arial", 11, "bold"),
            bg="#F0F8FF",
            fg="#1DA1F2",
            padx=10,
            pady=10
        )
        progress_frame.pack(fill=tk.X, pady=(0, 10))

        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            progress_frame,
            variable=self.progress_var,
            maximum=100,
            mode='determinate',
            length=400
        )
        self.progress_bar.pack(fill=tk.X, pady=5)

        self.progress_label = tk.Label(
            progress_frame,
            text="Sẵn sàng...",
            font=("Arial", 10),
            bg="#F0F8FF",
            fg="#333"
        )
        self.progress_label.pack()

        # Log Frame
        log_frame = tk.LabelFrame(
            main_container,
            text="Nhật ký hoạt động",
            font=("Arial", 11, "bold"),
            bg="#F0F8FF",
            fg="#1DA1F2",
            padx=10,
            pady=10
        )
        log_frame.pack(fill=tk.BOTH, expand=True)

        # Scrollbar cho log
        log_scroll = tk.Scrollbar(log_frame)
        log_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.log_text = tk.Text(
            log_frame,
            height=10,
            font=("Consolas", 9),
            bg="#FFFFFF",
            fg="#000000",
            yscrollcommand=log_scroll.set,
            wrap=tk.WORD
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        log_scroll.config(command=self.log_text.yview)

        # Cấu hình tag cho log màu sắc
        self.log_text.tag_config("info", foreground="#1DA1F2")
        self.log_text.tag_config("success", foreground="#28a745")
        self.log_text.tag_config("error", foreground="#dc3545")
        self.log_text.tag_config("warning", foreground="#FFA500")

        # Khởi tạo mode
        self.toggle_mode()

        # Log khởi động
        self.log_message("✅ Ứng dụng đã sẵn sàng!", "success")
        self.log_message("📌 Chọn chế độ tải và điền thông tin để bắt đầu", "info")

    def toggle_mode(self):
        """Chuyển đổi giữa chế độ tải"""
        if self.download_mode.get() == "all":
            self.single_frame.pack_forget()
            self.all_frame.pack(fill=tk.X, pady=(0, 10), after=self.mode_frame)
        else:
            self.all_frame.pack_forget()
            self.single_frame.pack(fill=tk.X, pady=(0, 10), after=self.mode_frame)

    def prepare_tiktok_url(self, url):
        """Thêm query params để bypass bot detection"""
        if not url:
            return url

        # Thêm webapp params nếu chưa có
        if 'is_from_webapp' not in url:
            separator = '&' if '?' in url else '?'
            url = f"{url}{separator}is_from_webapp=1&sender_device=pc"

        return url

    def select_folder(self):
        """Chọn thư mục lưu file"""
        folder = filedialog.askdirectory(
            title="Chọn thư mục lưu video",
            initialdir=self.download_path.get()
        )
        if folder:
            self.download_path.set(folder)
            self.save_config()
            self.log_message(f"📁 Đã chọn thư mục: {folder}", "info")

    def log_message(self, message, level="info"):
        """Thêm message vào log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_msg = f"[{timestamp}] {message}\n"

        self.log_text.insert(tk.END, formatted_msg, level)
        self.log_text.see(tk.END)
        self.root.update_idletasks()

    def update_progress(self, current, total, message=""):
        """Cập nhật thanh tiến trình"""
        if total > 0:
            percent = (current / total) * 100
            self.progress_var.set(percent)
            if message:
                self.progress_label.config(text=f"{message} ({current}/{total}) - {percent:.1f}%")
            else:
                self.progress_label.config(text=f"{current}/{total} - {percent:.1f}%")
        else:
            self.progress_var.set(0)
            self.progress_label.config(text=message)
        self.root.update_idletasks()

    def reset_form(self):
        """Reset form về trạng thái ban đầu"""
        self.single_url.set("")
        self.max_videos.set("")
        self.progress_var.set(0)
        self.progress_label.config(text="Sẵn sàng...")
        self.log_text.delete(1.0, tk.END)
        self.log_message("🔄 Đã làm mới form", "info")
        self.download_btn.config(state=tk.NORMAL)

    def update_ytdlp(self):
        """Cập nhật yt-dlp lên phiên bản mới nhất"""
        self.log_message("🔧 Đang cập nhật yt-dlp...", "info")
        self.download_btn.config(state=tk.DISABLED)

        def do_update():
            try:
                import subprocess
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--upgrade", "yt-dlp"],
                    capture_output=True,
                    text=True,
                    timeout=60
                )

                if result.returncode == 0:
                    self.log_message("✅ Cập nhật yt-dlp thành công!", "success")
                    self.log_message("📌 Bạn có thể tải video ngay bây giờ", "info")
                else:
                    self.log_message(f"⚠️ Cập nhật thất bại: {result.stderr}", "warning")

            except Exception as e:
                self.log_message(f"❌ Lỗi khi cập nhật: {str(e)}", "error")
            finally:
                self.download_btn.config(state=tk.NORMAL)

        thread = threading.Thread(target=do_update, daemon=True)
        thread.start()

    def start_download(self):
        """Bắt đầu tải video"""
        mode = self.download_mode.get()

        if mode == "all":
            username = self.username.get().strip().replace('@', '')
            if not username:
                self.log_message("❌ Vui lòng nhập username TikTok!", "error")
                return

            max_input = self.max_videos.get().strip()
            max_videos = int(max_input) if max_input.isdigit() else None

            # Chạy trong thread riêng
            self.download_btn.config(state=tk.DISABLED)
            thread = threading.Thread(
                target=self.download_channel,
                args=(username, max_videos),
                daemon=True
            )
            thread.start()

        else:  # single
            url = self.single_url.get().strip()
            if not url:
                self.log_message("❌ Vui lòng nhập URL video!", "error")
                return

            self.download_btn.config(state=tk.DISABLED)
            thread = threading.Thread(
                target=self.download_single_video,
                args=(url,),
                daemon=True
            )
            thread.start()

        # Lưu cài đặt
        self.save_config()

    def download_single_video(self, url):
        """Tải 1 video đơn"""
        try:
            # Chuẩn bị URL
            url = self.prepare_tiktok_url(url)
            self.log_message(f"🔄 Đang tải video: {url}", "info")
            self.update_progress(0, 1, "Đang tải video")

            output_path = os.path.join(self.download_path.get(), "%(title)s.%(ext)s")

            ydl_opts = {
                # Format: ĐẢM BẢO TẢI VIDEO, KHÔNG CHỈ AUDIO
                'format': 'best[height>=720][ext=mp4]/best[height>=480][ext=mp4]/best[ext=mp4]/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best',
                'outtmpl': output_path,
                'quiet': False,
                'no_warnings': False,
                'progress_hooks': [self.yt_dlp_progress_hook],

                # MERGE video+audio nếu tách rời
                'merge_output_format': 'mp4',

                # Headers mạnh hơn
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                    'Referer': 'https://www.tiktok.com/',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                },

                # Extractor args cải tiến
                'extractor_args': {
                    'tiktok': {
                        'webpage_download_retries': 5,
                    }
                },

                # Retry options
                'retries': 5,
                'fragment_retries': 5,
                'skip_unavailable_fragments': True,

                # Sleep để tránh rate limit
                'sleep_interval': 1,
                'max_sleep_interval': 3,

                # Fragment downloads
                'concurrent_fragment_downloads': 5,

                # Post-processing: đảm bảo có video
                'postprocessors': [{
                    'key': 'FFmpegVideoConvertor',
                    'preferedformat': 'mp4',
                }],
            }

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                title = info.get('title', 'Unknown')

            self.update_progress(1, 1, "Hoàn thành")
            self.log_message(f"✅ Đã tải xong: {title}", "success")
            self.log_message(f"📁 Lưu tại: {self.download_path.get()}", "success")

        except Exception as e:
            import re
            error_msg = str(e)
            error_msg = re.sub(r'\x1b\[[0-9;]*m', '', error_msg)  # Remove ANSI codes
            self.log_message(f"❌ Lỗi: {error_msg}", "error")
        finally:
            self.download_btn.config(state=tk.NORMAL)

    def download_channel(self, username, max_videos=None):
        """Tải toàn bộ kênh"""
        import time
        import re

        try:
            # Bước 1: Lấy danh sách video
            self.log_message(f"🔄 Đang lấy thông tin từ @{username}...", "info")
            videos = self.get_video_list(username, max_videos)

            if not videos:
                self.log_message("❌ Không tìm thấy video nào!", "error")
                self.download_btn.config(state=tk.NORMAL)
                return

            total = len(videos)
            self.log_message(f"📊 Tìm thấy {total} video", "success")

            # Bước 2: Tải từng video
            self.log_message("⬇️ Bắt đầu tải video...", "info")
            success_count = 0
            failed_videos = []

            for i, video in enumerate(videos, 1):
                try:
                    self.update_progress(i-1, total, f"Đang tải video {i}/{total}")
                    video_title = video.get('title', 'Unknown')[:50]
                    self.log_message(f"📥 [{i}/{total}] {video_title}...", "info")

                    # Chuẩn bị URL với query params
                    video_url = self.prepare_tiktok_url(video['url'])

                    output_path = os.path.join(
                        self.download_path.get(),
                        f"{username}",
                        f"{i:03d}_%(title)s.%(ext)s"
                    )

                    ydl_opts = {
                        'format': 'best[height>=720][ext=mp4]/best[height>=480][ext=mp4]/best[ext=mp4]/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best',
                        'outtmpl': output_path,
                        'quiet': True,
                        'no_warnings': True,
                        'ignoreerrors': True,

                        # MERGE video+audio nếu tách rời
                        'merge_output_format': 'mp4',

                        # Headers mạnh hơn
                        'http_headers': {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                            'Referer': 'https://www.tiktok.com/',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Accept-Encoding': 'gzip, deflate, br',
                            'DNT': '1',
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                        },

                        # Extractor args cải tiến
                        'extractor_args': {
                            'tiktok': {
                                'webpage_download_retries': 5,
                            }
                        },

                        # Retry options
                        'retries': 5,
                        'fragment_retries': 5,
                        'skip_unavailable_fragments': True,

                        # Sleep để tránh rate limit
                        'sleep_interval': 2,
                        'max_sleep_interval': 5,
                        'sleep_interval_requests': 1,

                        # Fragment downloads
                        'concurrent_fragment_downloads': 5,
                    }

                    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                        ydl.download([video_url])

                    success_count += 1
                    self.log_message(f"   ✅ Thành công!", "success")

                    # Sleep giữa các video để tránh rate limit
                    if i < total:
                        delay = 2 + (i % 3)  # 2-4 giây, thay đổi
                        self.log_message(f"   ⏳ Chờ {delay}s trước video tiếp theo...", "info")
                        time.sleep(delay)

                except Exception as e:
                    error_msg = str(e)
                    # Loại bỏ ANSI color codes
                    error_msg = re.sub(r'\x1b\[[0-9;]*m', '', error_msg)
                    self.log_message(f"   ⚠️ Lỗi: {error_msg[:100]}", "warning")
                    failed_videos.append((i, video_title))

            # Hoàn thành
            self.update_progress(total, total, "Hoàn thành!")
            self.log_message("=" * 50, "info")
            self.log_message(f"🎉 ĐÃ HOÀN THÀNH!", "success")
            self.log_message(f"✅ Tải thành công: {success_count}/{total} video", "success")

            if failed_videos:
                self.log_message(f"⚠️ Thất bại: {len(failed_videos)}/{total} video", "warning")
                self.log_message("📋 Danh sách video lỗi:", "warning")
                for idx, title in failed_videos[:5]:  # Chỉ hiện 5 video đầu
                    self.log_message(f"   - Video {idx}: {title}", "warning")
                if len(failed_videos) > 5:
                    self.log_message(f"   ... và {len(failed_videos)-5} video khác", "warning")

            self.log_message(f"📁 Lưu tại: {os.path.join(self.download_path.get(), username)}", "success")
            self.log_message("=" * 50, "info")

        except Exception as e:
            error_msg = str(e)
            error_msg = re.sub(r'\x1b\[[0-9;]*m', '', error_msg)
            self.log_message(f"❌ Lỗi nghiêm trọng: {error_msg}", "error")
        finally:
            self.download_btn.config(state=tk.NORMAL)

    def get_video_list(self, username, max_videos=None):
        """Lấy danh sách video từ kênh"""
        url = f"https://www.tiktok.com/@{username}"

        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
            'force_generic_extractor': False,
            'playlistend': max_videos,
            'skip_download': True,
            'ignoreerrors': True,
            'no_color': True,
        }

        videos = []

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)

                if not info:
                    return videos

                channel_name = info.get('title', username)
                self.log_message(f"📺 Kênh: {channel_name}", "info")

                if 'entries' in info:
                    total = len(info['entries'])
                    for i, entry in enumerate(info['entries'], 1):
                        if entry:
                            video_data = {
                                'index': i,
                                'id': entry.get('id', ''),
                                'url': entry.get('url', f"https://www.tiktok.com/@{username}/video/{entry.get('id', '')}"),
                                'title': entry.get('title', f'Video {i}'),
                                'duration': entry.get('duration', 0),
                            }
                            videos.append(video_data)

                            if i % 10 == 0 or i == total:
                                self.log_message(f"   📋 Đã lấy {i}/{total} video...", "info")

        except Exception as e:
            self.log_message(f"❌ Lỗi khi lấy danh sách: {str(e)}", "error")

        return videos

    def yt_dlp_progress_hook(self, d):
        """Hook để hiển thị tiến trình tải của yt-dlp"""
        if d['status'] == 'downloading':
            if 'downloaded_bytes' in d and 'total_bytes' in d:
                percent = (d['downloaded_bytes'] / d['total_bytes']) * 100
                self.progress_var.set(percent)
        elif d['status'] == 'finished':
            self.progress_var.set(100)

def main():
    root = tk.Tk()
    app = TikTokDownloaderGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
