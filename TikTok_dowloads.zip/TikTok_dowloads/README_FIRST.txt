════════════════════════════════════════════════════════════
    📦 HƯỚNG DẪN NHANH - ĐỌC ĐẦU TIÊN
    TikTok Video Downloader
    Vũ Vẫn Vậy - Zalo: 0983740967
════════════════════════════════════════════════════════════

🚀 CÁCH NHANH NHẤT:

1. Double click: build_exe.bat
2. Đợi 2-3 phút
3. Vào thư mục "dist"
4. Copy file "TikTok_Downloader.exe"
5. Dán vào USB/máy khác
6. Double click để chạy

✅ XONG! Không cần cài gì thêm!

════════════════════════════════════════════════════════════

📁 CẤU TRÚC THỨ MỤC:

📦 TikTok_dowloads/
├── TikTok_GUI.py           ← Code gốc
├── Main.py                 ← Code console (không dùng)
├── requirements.txt        ← Danh sách thư viện
├── build_exe.bat          ← BUILD EXE (CHẠY CÁI NÀY!)
├── HUONG_DAN_CHAY.txt     ← Hướng dẫn chi tiết
└── dist/                   ← Thư mục chứa EXE sau khi build
    └── TikTok_Downloader.exe

════════════════════════════════════════════════════════════

⚡ NHANH GỌN:

Chỉ cần 1 file: TikTok_Downloader.exe
Chạy được trên mọi máy Windows!

════════════════════════════════════════════════════════════
