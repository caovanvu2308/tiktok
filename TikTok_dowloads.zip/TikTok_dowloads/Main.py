import yt_dlp
import json
import sys
from datetime import datetime

def get_tiktok_video_links(username, max_videos=None):
    """
    Lấy toàn bộ links video từ kênh TikTok
    
    Args:
        username (str): Tên kênh TikTok (không có @)
        max_videos (int): Số lượng video tối đa cần lấy (None = tất cả)
    
    Returns:
        list: Danh sách các dictionary chứa thông tin video
    """
    url = f"https://www.tiktok.com/@{username}"
    
    # Cấu hình yt-dlp
    ydl_opts = {
        'quiet': True,  # Giảm log
        'no_warnings': True,
        'extract_flat': True,  # Chỉ lấy metadata, không tải
        'force_generic_extractor': False,
        'playlistend': max_videos,  # Giới hạn số video
        'skip_download': True,  # Không tải video
        'ignoreerrors': True,  # Bỏ qua lỗi nếu có
        'no_color': True,
    }
    
    videos = []
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            print(f"🔄 Đang lấy thông tin từ: @{username}")
            
            # Lấy thông tin kênh
            info = ydl.extract_info(url, download=False)
            
            if not info:
                print("❌ Không tìm thấy kênh hoặc có lỗi!")
                return videos
            
            print(f"📊 Tìm thấy kênh: {info.get('title', username)}")
            print(f"👥 Số video: {info.get('video_count', 'N/A')}")
            
            # Lấy danh sách video từ playlist
            if 'entries' in info:
                total_videos = len(info['entries'])
                print(f"🎬 Đang xử lý {total_videos} video...")
                
                for i, entry in enumerate(info['entries'], 1):
                    if entry:
                        video_data = {
                            'index': i,
                            'id': entry.get('id', ''),
                            'url': entry.get('url', f"https://www.tiktok.com/@{username}/video/{entry.get('id', '')}"),
                            'title': entry.get('title', ''),
                            'duration': entry.get('duration', 0),
                            'view_count': entry.get('view_count', 0),
                            'like_count': entry.get('like_count', 0),
                            'comment_count': entry.get('comment_count', 0),
                            'upload_date': entry.get('upload_date', ''),
                        }
                        videos.append(video_data)
                        
                        # Hiển thị progress
                        if i % 10 == 0 or i == total_videos:
                            print(f"✅ Đã lấy {i}/{total_videos} video")
            
            print(f"\n🎉 Hoàn thành! Tổng số video: {len(videos)}")
            
    except Exception as e:
        print(f"❌ Lỗi: {str(e)}")
        sys.exit(1)
    
    return videos

def save_links_to_file(videos, username, format='txt'):
    """Lưu links ra file"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"tiktok_{username}_{timestamp}"
    
    if format == 'txt':
        filename += '.txt'
        with open(filename, 'w', encoding='utf-8') as f:
            for video in videos:
                f.write(f"{video['url']}\n")
        print(f"📁 Đã lưu {len(videos)} links vào: {filename}")
    
    elif format == 'json':
        filename += '.json'
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(videos, f, ensure_ascii=False, indent=2)
        print(f"📁 Đã lưu metadata vào: {filename}")
    
    elif format == 'csv':
        import csv
        filename += '.csv'
        with open(filename, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=videos[0].keys())
            writer.writeheader()
            writer.writerows(videos)
        print(f"📁 Đã lưu dữ liệu vào: {filename}")
    
    return filename

def export_for_ytdlp(videos, username):
    """Tạo file để yt-dlp có thể tải hàng loạt"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"download_list_{username}_{timestamp}.txt"
    
    with open(filename, 'w', encoding='utf-8') as f:
        for video in videos:
            f.write(f"{video['url']}\n")
    
    print(f"\n📋 Để tải toàn bộ video, dùng lệnh:")
    print(f"yt-dlp -a {filename} -o \"%(title)s.%(ext)s\"")
    print(f"yt-dlp -a {filename} --format \"best[height<=720]\" -o \"%(title)s.%(ext)s\"")
    
    return filename

def main():
    print("=" * 50)
    print("TIKTOK VIDEO LINKS EXTRACTOR")
    print("=" * 50)
    
    # Nhập username từ user
    if len(sys.argv) > 1:
        username = sys.argv[1].replace('@', '')
    else:
        username = input("👉 Nhập username TikTok (không có @): ").strip().replace('@', '')
    
    if not username:
        print("❌ Vui lòng nhập username!")
        sys.exit(1)
    
    # Hỏi số lượng video
    max_input = input("👉 Số video tối đa (Enter để lấy tất cả): ").strip()
    max_videos = int(max_input) if max_input.isdigit() else None
    
    # Lấy links
    videos = get_tiktok_video_links(username, max_videos)
    
    if not videos:
        print("❌ Không có video nào được tìm thấy!")
        sys.exit(1)
    
    # Hiển thị menu lưu file
    print("\n" + "=" * 50)
    print("📝 LỰA CHỌN XUẤT FILE:")
    print("1. Chỉ lưu URLs (txt)")
    print("2. Lưu đầy đủ metadata (json)")
    print("3. Lưu cho yt-dlp batch download")
    print("4. Lưu tất cả các định dạng")
    print("5. Chỉ hiển thị, không lưu")
    
    choice = input("👉 Chọn [1-5]: ").strip()
    
    if choice == '1':
        save_links_to_file(videos, username, 'txt')
    elif choice == '2':
        save_links_to_file(videos, username, 'json')
    elif choice == '3':
        export_for_ytdlp(videos, username)
    elif choice == '4':
        save_links_to_file(videos, username, 'txt')
        save_links_to_file(videos, username, 'json')
        save_links_to_file(videos, username, 'csv')
        export_for_ytdlp(videos, username)
    elif choice == '5':
        # Hiển thị 5 video đầu tiên
        print("\n" + "=" * 50)
        print("📺 5 VIDEO ĐẦU TIÊN:")
        for i, video in enumerate(videos[:5], 1):
            print(f"\n{i}. {video['title'][:50]}...")
            print(f"   👁️  {video['view_count']:,} views | ❤️  {video['like_count']:,} likes")
            print(f"   🔗 {video['url']}")
        
        print(f"\n📋 Tổng cộng: {len(videos)} video")
    
    # Xuất ra terminal
    print("\n" + "=" * 50)
    print("🔗 DANH SÁCH URLS VIDEO:")
    for video in videos[:10]:  # Hiển thị 10 links đầu
        print(video['url'])
    
    if len(videos) > 10:
        print(f"... và {len(videos) - 10} video còn lại")

if __name__ == "__main__":
    main()